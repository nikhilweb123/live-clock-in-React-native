import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import MyButton from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Live Clock </Text>
      
      <Card>
        <MyButton color="blue" />
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 10,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#6666ff',
    padding: 20,
  },
  paragraph: {
    margin: 25,
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',color:'yellow'
  },
});
