import React, {Component} from 'react';
import { View, Text, StyleSheet } from 'react-native';


class LiveClock extends Component {
  
  constructor(props) {
    super(props);
    this.state = {date: new Date()};
  }

  componentDidMount() {
    setInterval(()=>this.tick(), 1000)
  }

  componentWillUnmount() {
    clearInterval(this.timerID);
  }

  tick() {
    this.setState({
      date: new Date()
    });
  }

 render(){
    return(
      <View style= {styles.container}>        
         <Text style={styles.clock}>{this.state.date.toLocaleTimeString('en-US')}</Text>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 50,
    backgroundColor:''
  },
  buttonStyle: {
    marginHorizontal: 50,
    marginTop: 10,
  },
  clock:{
    fontSize:30,
    fontFamily:'verdana'
  }
});


export default LiveClock;